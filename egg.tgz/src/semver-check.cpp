// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("semver check\n", stdout);
  return lionss_run_workload("semver-check");
}
